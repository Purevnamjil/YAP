$(document).ready(function (e) {
  $("img[usemap]").rwdImageMaps();
});

$(document).ready(function () {
  $(".sdgslice").click(function () {
    $(".sgdphoto").toggleClass("sgdrot");
  });
});

$(document).ready(function () {
  $("#sgd1").click(function () {
    $(".sdgbox").css("background-color", "#EB1C2D");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №1");
    $(".sdgbox h3").text("Ядуурлыг устгах");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd2").click(function () {
    $(".sdgbox").css("background-color", "#D3A029");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №2");
    $(".sdgbox h3").text("Өлсгөлөнг зогсоох");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd3").click(function () {
    $(".sdgbox").css("background-color", "#279B48");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №3 ");
    $(".sdgbox h3").text("Эрүүл мэндийг дэмжих");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd4").click(function () {
    $(".sdgbox").css("background-color", "#C31F33");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №4 ");
    $(".sdgbox h3").text("Чанартай боловсролыг дэмжих");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd5").click(function () {
    $(".sdgbox").css("background-color", "#EF402B");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №5 ");
    $(".sdgbox h3").text("Жендэрийн эрх, тэгш байдлыг хангах");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd6").click(function () {
    $(".sdgbox").css("background-color", "#00AED9");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №6 ");
    $(".sdgbox h3").text(
      "Баталгаат ундны ус, ариун цэврийн байгууламжаар хангах"
    );
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd7").click(function () {
    $(".sdgbox").css("background-color", "#FDB713");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №7 ");
    $(".sdgbox h3").text("Сэргээгдэх эрчим хүчийг нэвтрүүлэх");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd8").click(function () {
    $(".sdgbox").css("background-color", "#8F1838");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №8 ");
    $(".sdgbox h3").text(
      "Эдийн засгийн өсөлт, баталгаат ажлын байрыг бий болгох"
    );
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd9").click(function () {
    $(".sdgbox").css("background-color", "#F36D25");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №9 ");
    $(".sdgbox h3").text("Инноваци  болон дэд бүтцийн нэмэгдүүлэх");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd10").click(function () {
    $(".sdgbox").css("background-color", "#e21185");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №10 ");
    $(".sdgbox h3").text("Тэгш бус байдлыг бууруулах");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd11").click(function () {
    $(".sdgbox").css("background-color", "#F99D26");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №11 ");
    $(".sdgbox h3").text("Ээлтэй хот, иргэдийн оролцоог дэмжих");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd12").click(function () {
    $(".sdgbox").css("background-color", "#CF8D2A");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №12 ");
    $(".sdgbox h3").text("Хариуцлагатай хэрэглээг дэмжих");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd13").click(function () {
    $(".sdgbox").css("background-color", "#48773E");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №13 ");
    $(".sdgbox h3").text("Уур амьсгалын өөрчлөлтийн үр  нөлөөг багасгах");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd14").click(function () {
    $(".sdgbox").css("background-color", "#007DBC");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №14 ");
    $(".sdgbox h3").text("Далай, тэнгисийн нөөцийг хамгаалах");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd15").click(function () {
    $(".sdgbox").css("background-color", "#5DBB46");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №15 ");
    $(".sdgbox h3").text("Хуурай газрын эко системийг хамгаалах");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd16").click(function () {
    $(".sdgbox").css("background-color", "#02558B");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №16 ");
    $(".sdgbox h3").text("Энх тайван, шударга ёсыг цогцлоох");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});

$(document).ready(function () {
  $("#sgd17").click(function () {
    $(".sdgbox").css("background-color", "#183668");
    $(".sdgbox h1").text("Тогтвортой Хөгжлийн Зорилт №17 ");
    $(".sdgbox h3").text("Хөгжлийн төлөөх түншлэлийг бэхжүүлэх");
    $(".sdgbox h5").text("зорилготой холбоотой товч мэдээлэл энд байрших юм.");
  });
});
